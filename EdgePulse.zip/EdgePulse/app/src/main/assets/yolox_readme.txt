Place your YOLOX TFLite model from Qualcomm AI Hub here.
The file should be named 'yolox_s_quantized.tflite' or update the name in YoloxDetector.kt.
Download the model from: https://github.com/qualcomm/ai-hub-models/tree/v0.57.3/src/qai_hub_models/models/yolox