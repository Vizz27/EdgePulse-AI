package com.example.edgepulse.ui.explore

object EquipmentDataProvider {
    val data = listOf(
        EquipmentType("Etch Systems", "Plasma and wet chemical etching for precise pattern transfer.", 
            listOf(
                Vendor("Lam Research", ToolSpec("Kiyo® Series", "Industry-leading conductor etch system.", listOf("High selectivity", "Atomic layer etching (ALE)", "Extreme uniformity"))),
                Vendor("Applied Materials", ToolSpec("Centris® AdvantEdge™", "High-performance silicon etch.", listOf("Precision material removal", "Multi-patterning support", "Integrated metrology"))),
                Vendor("Tokyo Electron (TEL)", ToolSpec("Tactras™ Vigus™", "Advanced dielectric etch system.", listOf("High-speed plasma control", "Stable long-run process", "Compact footprint"))),
                Vendor("Hitachi High-Tech", ToolSpec("9000 Series", "Microwave ECR plasma etch.", listOf("Low damage etching", "High aspect ratio", "Superior profile control"))),
                Vendor("SEMES", ToolSpec("MICRONUS", "Advanced wet etch and cleaning.", listOf("Efficient chemical usage", "High throughput", "Particle-free process"))),
                Vendor("Oxford Instruments", ToolSpec("PlasmaPro 100", "Versatile RIE/ICP etch tool.", listOf("Multi-wafer capability", "Fast process switching", "R&D to production scale"))),
                Vendor("Plasma-Therm", ToolSpec("Versaline®", "Flexible modular etch platform.", listOf("End-point detection", "High power density", "Customizable chamber"))),
                Vendor("SPTS Technologies", ToolSpec("Omega® Series", "Plasma etch for MEMS and Power.", listOf("Deep Reactive Ion Etching (DRIE)", "High tilt capability", "Exceptional etch rates"))),
                Vendor("GigaLane", ToolSpec("MAXER", "Inductively Coupled Plasma (ICP) Etcher.", listOf("LED/Display optimization", "Low COO", "Simplified maintenance"))),
                Vendor("Wonik IPS", ToolSpec("GEMINI", "Dry etch for semi-conductor manufacturing.", listOf("Reliable performance", "Cost-effective", "Global support")))
            )
        ),
        EquipmentType("Photolithography", "Using UV light to transfer geometric shapes to a photoresist.", 
            listOf(
                Vendor("ASML", ToolSpec("TWINSCAN EXE:5000", "High-NA Extreme Ultraviolet (EUV) lithography.", listOf("0.55 NA optics", "8nm resolution", "High productivity throughput"))),
                Vendor("Nikon", ToolSpec("NSR-S635E", "ArF immersion scanner.", listOf("Excellent overlay accuracy", "High stability", "Advanced alignment"))),
                Vendor("Canon", ToolSpec("FPA-1200NZ2C", "Nanoimprint lithography system.", listOf("Low cost of ownership", "High resolution", "Simple process"))),
                Vendor("EV Group (EVG)", ToolSpec("EVG®7200", "UV nanoimprint lithography (UV-NIL).", listOf("Large area processing", "Stamp replication", "High precision"))),
                Vendor("SUSS MicroTec", ToolSpec("MA/BA Gen4", "Advanced mask aligner.", listOf("Sub-micron resolution", "Top/bottom side alignment", "Versatile substrate handling"))),
                Vendor("Veeco", ToolSpec("AP300", "Advanced packaging lithography.", listOf("Dual side imaging", "Large depth of focus", "Cost-effective packaging"))),
                Vendor("JEOL", ToolSpec("JBX-8100FS", "Electron beam lithography.", listOf("Direct write capability", "Nanometer precision", "Variable beam current"))),
                Vendor("Heidelberg Instruments", ToolSpec("MLA150", "Maskless aligner.", listOf("Fast prototyping", "Non-contact exposure", "High flexibility"))),
                Vendor("Raith", ToolSpec("EBPG5150", "High-end electron beam lithography.", listOf("Full 200mm capability", "125kV acceleration", "Automated calibration"))),
                Vendor("NuFlare Technology", ToolSpec("EBM-9500", "Electron beam mask writer.", listOf("Extreme accuracy", "Stable beam", "Advanced data processing")))
            )
        ),
        EquipmentType("Deposition (CVD/PVD)", "Chemical and Physical Vapor Deposition for growing thin films.", 
            listOf(
                Vendor("Applied Materials", ToolSpec("Endura®", "The industry standard for PVD metallization.", listOf("Superior film quality", "High reliability", "Broad material range"))),
                Vendor("Tokyo Electron (TEL)", ToolSpec("Triase+™", "Advanced single wafer CVD system.", listOf("High step coverage", "Excellent uniformity", "Precise thickness control"))),
                Vendor("Lam Research", ToolSpec("ALTUS®", "Industry-leading tungsten CVD system.", listOf("Low resistance films", "Excellent gap fill", "High productivity"))),
                Vendor("ASM International", ToolSpec("Pulsar®", "High-productivity ALD system.", listOf("Atomic layer precision", "Superior film density", "Advanced material support"))),
                Vendor("Wonik IPS", ToolSpec("NOVA", "PECVD system for dielectric films.", listOf("Low temperature process", "High film stability", "Reliable mass production"))),
                Vendor("Jusung Engineering", ToolSpec("Eureka", "Innovative ALD and CVD solutions.", listOf("High wafer throughput", "Multi-layer capability", "Advanced plasma control"))),
                Vendor("Ulvac", ToolSpec("ENCORE", "Advanced sputtering system for packaging.", listOf("High-speed deposition", "Excellent adhesion", "Versatile substrate support"))),
                Vendor("Veeco Instruments", ToolSpec("GEN200®", "MBE system for compound semiconductors.", listOf("Ultra-high vacuum", "Precise layer control", "High material purity"))),
                Vendor("Denton Vacuum", ToolSpec("Discovery®", "Versatile sputtering and evaporation tool.", listOf("R&D to pilot scale", "Modular design", "Ease of operation"))),
                Vendor("Evatec", ToolSpec("HEXAGON", "Advanced thin film deposition for wireless.", listOf("High precision optics", "Low defect density", "Flexible configuration")))
            )
        ),
        EquipmentType("Thermal & Diffusion", "High-temperature furnace processes for oxidation and doping.", 
            listOf(
                Vendor("Tokyo Electron (TEL)", ToolSpec("TELINDY NEXT™", "Advanced vertical batch furnace.", listOf("High-speed processing", "Excellent uniformity", "Integrated metrology"))),
                Vendor("Applied Materials", ToolSpec("Vantage®", "Rapid Thermal Processing (RTP) system.", listOf("Precise temperature control", "Fast ramp rates", "Multi-gas capability"))),
                Vendor("Kokusai Electric", ToolSpec("VERTRON®", "Batch thermal processing system.", listOf("Large batch capability", "High temperature stability", "Reliable operation"))),
                Vendor("ASM International", ToolSpec("A412™", "Vertical furnace for large scale production.", listOf("High throughput", "Advanced automation", "Excellent process control"))),
                Vendor("Wonik IPS", ToolSpec("THERMA", "High performance diffusion furnace.", listOf("Stable process results", "Cost effective", "Global reliability"))),
                Vendor("SEMES", ToolSpec("GENIUS", "Advanced thermal processing system.", listOf("Precise doping control", "High uniformity", "Reliable mass production"))),
                Vendor("Centrotherm", ToolSpec("c.HORIZON", "High-end horizontal furnace.", listOf("Flexible configuration", "Advanced heating tech", "Superior gas delivery"))),
                Vendor("BTU International", ToolSpec("Pyramax™", "Reflow oven for advanced packaging.", listOf("Precise heat control", "High throughput", "Excellent gas management"))),
                Vendor("Thermco Systems", ToolSpec("9000 Series", "Vertical and horizontal furnaces.", listOf("High temperature accuracy", "Advanced control systems", "Customizable options"))),
                Vendor("Tempress", ToolSpec("CVD/Diffusion", "Horizontal furnace systems.", listOf("High volume manufacturing", "Proven reliability", "Advanced safety features")))
            )
        ),
        EquipmentType("Ion Implantation", "Accelerating ions into the wafer to modify electrical properties.", 
            listOf(
                Vendor("Applied Materials", ToolSpec("VIISta®", "High-current and medium-current implanters.", listOf("Precise dose control", "Advanced angle control", "High productivity"))),
                Vendor("Axcelis Technologies", ToolSpec("Purion™", "Complete line of ion implantation systems.", listOf("Exceptional beam quality", "Fast setup", "High reliability"))),
                Vendor("Nissin Ion Equipment", ToolSpec("EXCEED™", "High-energy ion implantation systems.", listOf("Stable beam delivery", "Wide energy range", "High throughput"))),
                Vendor("Sumitomo Heavy Industries", ToolSpec("SHI Ion", "Precision ion implantation for semiconductors.", listOf("Advanced beam transport", "High uniformity", "Reliable operation"))),
                Vendor("AIBT", ToolSpec("iPulsar", "Ion implanter for power devices.", listOf("High dose capability", "Low energy precision", "Advanced automation"))),
                Vendor("Intevac", ToolSpec("MATRIX", "Ion implantation for solar applications.", listOf("High volume production", "Uniform doping", "Cost-effective solution"))),
                Vendor("Kingstone Semiconductor", ToolSpec("Ion Pro", "Advanced ion implantation equipment.", listOf("Precision beam control", "Stable long-run performance", "High efficiency"))),
                Vendor("High Voltage Engineering", ToolSpec("HVE Systems", "Research scale ion implanters.", listOf("Extreme energy range", "High material versatility", "Precision engineering"))),
                Vendor("Danfysik", ToolSpec("Danfysik Implanter", "Specialized ion beam systems.", listOf("High beam purity", "Advanced magnetic control", "Customizable designs"))),
                Vendor("Epion", ToolSpec("GCIB", "Gas Cluster Ion Beam systems.", listOf("Surface smoothing", "Low damage processing", "Unique material modification")))
            )
        ),
        EquipmentType("Metrology & Inspection", "In-line measurement and defect inspection for process stability.", 
            listOf(
                Vendor("KLA Corporation", ToolSpec("Archer™ 700", "Advanced overlay metrology system.", listOf("High precision measurement", "Robust performance", "Automated diagnostics"))),
                Vendor("Applied Materials", ToolSpec("PROVision™", "Electron beam inspection for defects.", listOf("High resolution imaging", "Fast scan speeds", "AI-driven analysis"))),
                Vendor("ASML (HMI)", ToolSpec("eP5", "E-beam inspection for advanced nodes.", listOf("Multi-beam capability", "Nanometer sensitivity", "High throughput inspection"))),
                Vendor("Hitachi High-Tech", ToolSpec("CG7300", "Critical Dimension SEM (CD-SEM).", listOf("Extreme resolution", "High measurement stability", "Advanced automation"))),
                Vendor("Onto Innovation", ToolSpec("Atlas® V", "Optical metrology for complex structures.", listOf("Spectroscopic ellipsometry", "Fast data processing", "High accuracy"))),
                Vendor("Nova Ltd.", ToolSpec("Nova i500™", "Integrated optical metrology.", listOf("In-line monitoring", "Real-time feedback", "High precision optics"))),
                Vendor("Camtek", ToolSpec("Eagle i", "Advanced 2D/3D inspection.", listOf("High speed inspection", "Versatile substrate handling", "AI defect classification"))),
                Vendor("Bruker", ToolSpec("InSight", "Atomic Force Microscopy (AFM) metrology.", listOf("Nanometer-scale 3D mapping", "Non-destructive", "High resolution"))),
                Vendor("Zeiss", ToolSpec("MultiSEM", "Parallel beam electron microscope.", listOf("Fast large-area imaging", "Extreme throughput", "High image quality"))),
                Vendor("Rudolph Technologies", ToolSpec("Dragonfly™", "Macro defect inspection.", listOf("High sensitivity", "Fast processing", "Comprehensive reporting")))
            )
        ),
        EquipmentType("CMP (Planarization)", "Chemical Mechanical Planarization for flattening the wafer surface.", 
            listOf(
                Vendor("Applied Materials", ToolSpec("Reflexion® LK", "Industry-leading CMP system.", listOf("Precise material removal", "Integrated cleaning", "Advanced endpoint control"))),
                Vendor("Ebara Corporation", ToolSpec("FREX™", "Dry-in/Dry-out CMP system.", listOf("High reliability", "Excellent uniformity", "Low slurry consumption"))),
                Vendor("KC Tech", ToolSpec("K-CMP", "High performance CMP for advanced nodes.", listOf("Stable process control", "High throughput", "Global support"))),
                Vendor("Applied Chemical", ToolSpec("AC CMP", "Specialized planarization solutions.", listOf("Precision optics CMP", "Custom slurry support", "Reliable performance"))),
                Vendor("Lapmaster", ToolSpec("Model 20", "Versatile lapping and polishing.", listOf("Precise flatness control", "R&D to production", "Durable construction"))),
                Vendor("Okamoto Machine Tool", ToolSpec("SPP Series", "Advanced semiconductor polishing.", listOf("High precision mechanicals", "Stable long-term run", "Ease of maintenance"))),
                Vendor("Revasum", ToolSpec("6EZ", "CMP for silicon carbide (SiC).", listOf("Optimized for hard materials", "High removal rates", "Superior finish"))),
                Vendor("SEMES", ToolSpec("CMP-X", "Mass production CMP system.", listOf("High speed processing", "Reliable automation", "Low cost of ownership"))),
                Vendor("Strasbaugh", ToolSpec("n-CMP", "Modular CMP platform.", listOf("Flexible configuration", "Advanced process monitoring", "Reliable performance"))),
                Vendor("G&P Technology", ToolSpec("Poli Series", "Compact CMP for research.", listOf("User-friendly interface", "High versatility", "Precision control")))
            )
        )
        // More can be added here, but these two demonstrate the functionality
    )
}
