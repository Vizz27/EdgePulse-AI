package com.example.edgepulse.ui.explore

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.edgepulse.R
import com.example.edgepulse.databinding.FragmentChatBinding
import com.example.edgepulse.databinding.ItemChatMessageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class ChatFragment : Fragment() {

    companion object {
        private const val OPENROUTER_API_KEY = "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"
        private const val SARVAM_API_KEY = "sk_oo1dpiaj_oZsxc3YfvOYeNkFPjeC7Sfzw"
        private const val CHAT_MODEL_NAME = "tencent/hy3:free"
    }

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!
    private val messages = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter
    private lateinit var generativeModel: OpenRouterModel
    private var vendorName: String = ""
    private var toolName: String = ""
    private var toolDesc: String = ""

    private var mediaRecorder: MediaRecorder? = null
    private var audioFile: File? = null
    private var isRecording = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startRecording()
        } else {
            Toast.makeText(context, "Microphone permission required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        vendorName = arguments?.getString("vendorName") ?: ""
        toolName = arguments?.getString("toolName") ?: ""
        toolDesc = arguments?.getString("toolDesc") ?: ""

        activity?.title = "Assistant: $vendorName"

        generativeModel = OpenRouterModel(
            modelName = CHAT_MODEL_NAME,
            apiKey = OPENROUTER_API_KEY
        )

        val systemInstruction = """
            Persona: Professional Technical AI Assistant for $vendorName semiconductor systems.
            Context: $toolName ($toolDesc).
            
            Tone: Professional, authoritative, and context-aware. 
            Goal: Directly address the user's specific question with relatable technical guidance.
            
            Formatting Rules (STRICT):
            - Use **Side Heading:** format (with bold asterisks) for all section headers.
            - Use double newlines (\n\n) between every paragraph, heading, or bullet point.
            - Format using simple text and simple bullet points (-).
            - Avoid generic filler, but acknowledge the specific context of the user's query.
            - Return a polished, direct, and technically tailored answer.
            
            Instructions:
            1. Analyze the user's question and provide a response that relates specifically to their inquiry about the $toolName.
            2. For troubleshooting, provide structured step-by-step guidance tailored to the reported symptom.
            3. Ensure all information is human-readable, technically accurate for $vendorName, and optimized for engineering use.
        """.trimIndent()

        adapter = ChatAdapter(messages)
        binding.rvChatMessages.layoutManager = LinearLayoutManager(context)
        binding.rvChatMessages.adapter = adapter

        // Add initial message
        addMessage(ChatMessage("Welcome to the $vendorName Technical Assistant. I am ready to assist you with the $toolName. Please specify your query or report a system status.", false))

        binding.btnSend.setOnClickListener {
            val prompt = binding.etMessage.text.toString()
            if (prompt.isNotBlank()) {
                sendMessage(prompt, systemInstruction)
                binding.etMessage.text.clear()
            }
        }

        binding.btnVoice.setOnClickListener {
            if (!isRecording) {
                checkPermissionAndStartRecording()
            } else {
                stopRecordingAndTranscribe()
            }
        }
    }

    private fun checkPermissionAndStartRecording() {
        when {
            ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                startRecording()
            }
            else -> {
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private var startTime: Long = 0

    private fun startRecording() {
        try {
            audioFile = File(requireContext().cacheDir, "voice_input.m4a")
            startTime = System.currentTimeMillis()
            mediaRecorder = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                MediaRecorder(requireContext())
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioChannels(1) // Mono for better STT
                setAudioSamplingRate(16000) // Lower sampling rate is often better for STT
                setAudioEncodingBitRate(32000)
                setOutputFile(audioFile?.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            binding.btnVoice.setColorFilter(ContextCompat.getColor(requireContext(), R.color.accent_orange))
            Toast.makeText(context, "Recording... Speak now", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e("ChatFragment", "Recording failed", e)
            Toast.makeText(context, "Mic error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecordingAndTranscribe() {
        try {
            // Ensure recording lasts at least 1 second to avoid IllegalStateException
            if (System.currentTimeMillis() - startTime < 1000) {
                Thread.sleep(1000 - (System.currentTimeMillis() - startTime))
            }
            
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
            isRecording = false
            binding.btnVoice.clearColorFilter()
            
            if (audioFile != null && audioFile!!.exists() && audioFile!!.length() > 100) {
                Log.d("ChatFragment", "Recorded file size: ${audioFile!!.length()} bytes")
                Toast.makeText(context, "Transcribing...", Toast.LENGTH_SHORT).show()
                transcribeAudio()
            } else {
                Toast.makeText(context, "Audio file is empty. Check microphone permissions.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("ChatFragment", "Stop recording failed", e)
            Toast.makeText(context, "Stop recording failed", Toast.LENGTH_SHORT).show()
            
            // Clean up on error
            mediaRecorder?.release()
            mediaRecorder = null
            isRecording = false
            binding.btnVoice.clearColorFilter()
        }
    }

    private fun transcribeAudio() {
        val file = audioFile ?: return
        _binding?.pbLoading?.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                val sarvamModel = SarvamSTTModel(apiKey = SARVAM_API_KEY)
                val result = sarvamModel.transcribe(file)
                if (_binding != null) {
                    if (!result.isNullOrBlank()) {
                        binding.etMessage.setText(result)
                    } else if (result == "") {
                        Toast.makeText(context, "No speech detected. Try speaking louder or moving to a quieter area.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Server did not return a transcript. Check your API key or connection.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("ChatFragment", "STT Error", e)
                if (_binding != null) {
                    Toast.makeText(context, "Transcription Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                _binding?.pbLoading?.visibility = View.GONE
            }
        }
    }

    private fun sendMessage(prompt: String, systemInstruction: String) {
        addMessage(ChatMessage(prompt, true))
        _binding?.pbLoading?.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                // Sending system instruction and user prompt as separate messages for better Llama performance
                val response = generativeModel.generateContent(systemInstruction, prompt)
                val finalRawText = response.text ?: "I'm sorry, I couldn't generate a response."
                
                if (_binding != null) {
                    addMessage(ChatMessage(formatResponseText(finalRawText), false))
                }

            } catch (e: Exception) {
                Log.e("ChatFragment", "OpenRouter Error", e)
                if (_binding != null) {
                    addMessage(ChatMessage("Error: ${e.message}", false))
                }
            } finally {
                _binding?.pbLoading?.visibility = View.GONE
            }
        }
    }

    private fun formatResponseText(text: String): String {
        return text.replace("###", "")
            .replace("##", "")
            .replace("#", "")
            .replace("`", "")
            .replace(Regex("\\*\\*(.*?)\\*\\*"), "<b>$1</b>")
            .replace("\n", "<br>")
            .trim()
    }

    private fun addMessage(message: ChatMessage) {
        messages.add(message)
        adapter.notifyItemInserted(messages.size - 1)
        binding.rvChatMessages.scrollToPosition(messages.size - 1)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mediaRecorder?.release()
        _binding = null
    }

    data class ChatMessage(val text: String, val isUser: Boolean)

    inner class ChatAdapter(private val items: List<ChatMessage>) :
        RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

        inner class ViewHolder(private val itemBinding: ItemChatMessageBinding) :
            RecyclerView.ViewHolder(itemBinding.root) {
            fun bind(message: ChatMessage) {
                itemBinding.tvMessageText.text = HtmlCompat.fromHtml(message.text, HtmlCompat.FROM_HTML_MODE_LEGACY)
                val params = itemBinding.cvMessage.layoutParams as LinearLayout.LayoutParams
                if (message.isUser) {
                    itemBinding.llMessageContainer.gravity = Gravity.END
                    itemBinding.cvMessage.setCardBackgroundColor(resources.getColor(R.color.accent_orange, null))
                    itemBinding.tvMessageText.setTextColor(resources.getColor(R.color.white, null))
                    params.marginStart = 48
                    params.marginEnd = 0
                } else {
                    itemBinding.llMessageContainer.gravity = Gravity.START
                    itemBinding.cvMessage.setCardBackgroundColor(resources.getColor(R.color.white, null))
                    itemBinding.tvMessageText.setTextColor(resources.getColor(R.color.text_main, null))
                    params.marginStart = 0
                    params.marginEnd = 48
                }
                itemBinding.cvMessage.layoutParams = params
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemChatMessageBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(items[position])
        }

    override fun getItemCount() = items.size
    }

    /**
     * OpenRouter Implementation to replace Google Generative AI SDK
     */
    class OpenRouterModel(private val modelName: String, private val apiKey: String) {
        suspend fun generateContent(systemMessage: String, userPrompt: String): OpenRouterResponse = withContext(Dispatchers.IO) {
            try {
                val url = URL("https://openrouter.ai/api/v1/chat/completions")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $apiKey")
                conn.setRequestProperty("HTTP-Referer", "https://github.com/EdgePulse") 
                conn.setRequestProperty("X-Title", "EdgePulse App")
                conn.doOutput = true

                // Correctly structured messages array as requested
                val json = JSONObject().apply {
                    put("model", modelName)
                    put("messages", JSONArray().apply {
                        // System role for instructions
                        put(JSONObject().apply {
                            put("role", "system")
                            put("content", systemMessage)
                        })
                        // User role for the specific question
                        put(JSONObject().apply {
                            put("role", "user")
                            put("content", userPrompt)
                        })
                    })
                }

                conn.outputStream.use { it.write(json.toString().toByteArray()) }

                if (conn.responseCode == 200) {
                    val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                    val responseJson = JSONObject(responseText)
                    val content = responseJson.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                    OpenRouterResponse(content)
                } else if (conn.responseCode == 429) {
                    Log.e("OpenRouter", "Rate limit exceeded (429)")
                    OpenRouterResponse("Error 429: The free model is currently busy or rate-limited. Please wait a moment or try again later.")
                } else {
                    val errorBody = conn.errorStream?.bufferedReader()?.use { it.readText() }
                    Log.e("OpenRouter", "Error ${conn.responseCode}: $errorBody")
                    OpenRouterResponse("Error ${conn.responseCode}: $errorBody")
                }
            } catch (e: Exception) {
                Log.e("OpenRouter", "Request failed", e)
                OpenRouterResponse("Error: ${e.message}")
            }
        }
    }

    data class OpenRouterResponse(val text: String?)

    /**
     * Sarvam AI STT Implementation
     */
    class SarvamSTTModel(private val apiKey: String) {
        suspend fun transcribe(audioFile: File): String? = withContext(Dispatchers.IO) {
            try {
                val boundary = "Boundary-${System.currentTimeMillis()}"
                val url = URL("https://api.sarvam.ai/speech-to-text")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                conn.setRequestProperty("api-subscription-key", apiKey)
                conn.doOutput = true
                conn.connectTimeout = 30000
                conn.readTimeout = 30000

                conn.outputStream.use { output ->
                    output.write("--$boundary\r\n".toByteArray())
                    output.write("Content-Disposition: form-data; name=\"file\"; filename=\"${audioFile.name}\"\r\n".toByteArray())
                    // Changed to audio/mpeg which is a common safe type for m4a/aac
                    output.write("Content-Type: audio/mpeg\r\n\r\n".toByteArray())
                    audioFile.inputStream().use { input ->
                        input.copyTo(output)
                    }
                    output.write("\r\n--$boundary\r\n".toByteArray())
                    output.write("Content-Disposition: form-data; name=\"model\"\r\n\r\n".toByteArray())
                    output.write("saaras:v3\r\n".toByteArray())
                    output.write("--$boundary\r\n".toByteArray())
                    output.write("Content-Disposition: form-data; name=\"mode\"\r\n\r\n".toByteArray())
                    output.write("transcribe\r\n".toByteArray())
                    output.write("--$boundary\r\n".toByteArray())
                    output.write("Content-Disposition: form-data; name=\"language_code\"\r\n\r\n".toByteArray())
                    output.write("en-IN\r\n".toByteArray())
                    output.write("--$boundary--\r\n".toByteArray())
                }

                val responseCode = conn.responseCode
                if (responseCode == 200) {
                    val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                    Log.d("SarvamSTT", "Success: $responseText")
                    val json = JSONObject(responseText)
                    
                    // Comprehensive extraction for saarika:v1 and other models
                    var transcript = json.optString("transcript", "")
                    if (transcript.isBlank()) transcript = json.optString("text", "")
                    if (transcript.isBlank()) transcript = json.optString("utterance", "")
                    
                    // Handle nested structures
                    if (transcript.isBlank() && json.has("data")) {
                        val data = json.optJSONObject("data")
                        transcript = data?.optString("transcript") ?: data?.optString("text") ?: ""
                    }
                    
                    if (transcript.isBlank() && json.has("results")) {
                        val results = json.optJSONArray("results")
                        if (results != null && results.length() > 0) {
                            val first = results.optJSONObject(0)
                            transcript = first?.optString("transcript") ?: first?.optString("text") ?: ""
                        }
                    }
                    
                    transcript
                } else {
                    val errorBody = conn.errorStream?.bufferedReader()?.use { it.readText() }
                    Log.e("SarvamSTT", "HTTP $responseCode: $errorBody")
                    null
                }
            } catch (e: Exception) {
                Log.e("SarvamSTT", "Network failed", e)
                null
            }
        }
    }
}
