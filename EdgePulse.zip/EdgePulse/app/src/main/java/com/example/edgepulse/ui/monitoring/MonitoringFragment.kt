package com.example.edgepulse.ui.monitoring

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.edgepulse.R
import com.example.edgepulse.databinding.FragmentMonitoringBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.random.Random

class MonitoringFragment : Fragment() {

    private var _binding: FragmentMonitoringBinding? = null
    private val binding get() = _binding!!

    private val equipmentList = listOf("Etcher-01", "CVD-05", "Litho-A2", "Diff-B3", "Ion-X9", "Metrology-M1")

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMonitoringBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvEquipment.layoutManager = LinearLayoutManager(context)
        binding.rvEquipment.adapter = EquipmentAdapter(equipmentList) { equipment ->
            showParametersPopup(equipment)
        }
    }

    private fun showParametersPopup(equipment: String) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_equipment_details, null)
        
        dialogView.findViewById<TextView>(R.id.tv_dialog_title).text = equipment
        dialogView.findViewById<TextView>(R.id.tv_dialog_temp).text = "${Random.nextInt(150, 450)} °C"
        dialogView.findViewById<TextView>(R.id.tv_dialog_rf).text = "${Random.nextInt(500, 2000)} W"
        dialogView.findViewById<TextView>(R.id.tv_dialog_sih4).text = "${Random.nextInt(10, 100)} sccm"
        dialogView.findViewById<TextView>(R.id.tv_dialog_nh3).text = "${Random.nextInt(50, 500)} sccm"
        dialogView.findViewById<TextView>(R.id.tv_dialog_n2).text = "${Random.nextInt(1000, 5000)} sccm"
        dialogView.findViewById<TextView>(R.id.tv_dialog_pressure).text = "${Random.nextInt(100, 1000)} mTorr"
        dialogView.findViewById<TextView>(R.id.tv_dialog_time).text = "${Random.nextInt(30, 300)} s"

        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btn_close_dialog).setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    inner class EquipmentAdapter(
        private val items: List<String>,
        private val onItemClick: (String) -> Unit
    ) : RecyclerView.Adapter<EquipmentAdapter.ViewHolder>() {

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val textView: TextView = view.findViewById(R.id.tv_equipment_name)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_equipment, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.textView.text = items[position]
            holder.itemView.setOnClickListener { onItemClick(items[position]) }
        }

        override fun getItemCount() = items.size
    }
}