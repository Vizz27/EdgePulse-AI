package com.example.edgepulse.ui.explore

data class ToolSpec(
    val model: String,
    val description: String,
    val keyFeatures: List<String>
)

data class Vendor(
    val name: String,
    val toolSpec: ToolSpec
)

data class EquipmentType(
    val name: String,
    val description: String,
    val vendors: List<Vendor>
)
