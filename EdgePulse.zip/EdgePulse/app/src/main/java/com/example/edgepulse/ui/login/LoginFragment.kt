package com.example.edgepulse.ui.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.edgepulse.R
import com.example.edgepulse.databinding.FragmentLoginBinding

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnLogin.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            if (!email.endsWith("@gmail.com")) {
                binding.emailLayout.error = "Please use a @gmail.com address"
                return@setOnClickListener
            } else {
                binding.emailLayout.error = null
            }

            // Password length > 1
            if (password.length <= 1) {
                binding.passwordLayout.error = "Password must be at least 2 characters"
                return@setOnClickListener
            } else {
                binding.passwordLayout.error = null
            }

            val role = if (binding.roleAdmin.isChecked) "Administrator" else "Operator"
            Toast.makeText(context, "Welcome, $role", Toast.LENGTH_SHORT).show()
            
            findNavController().navigate(R.id.action_nav_login_to_nav_home)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}