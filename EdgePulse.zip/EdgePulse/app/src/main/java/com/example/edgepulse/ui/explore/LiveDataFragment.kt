package com.example.edgepulse.ui.explore

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.edgepulse.databinding.FragmentLiveDataBinding
import com.example.edgepulse.ui.ArduinoViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

class LiveDataFragment : Fragment() {

    private var _binding: FragmentLiveDataBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ArduinoViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLiveDataBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[ArduinoViewModel::class.java]

        lifecycleScope.launch {
            viewModel.arduinoData.collectLatest { data ->
                // 1. Metrology
                binding.tvMetThick.text = String.format(Locale.US, "%.1f nm", data.incomingThickness)
                binding.tvMetStress.text = String.format(Locale.US, "%.1f MPa", data.incomingStress)
                binding.tvMetBow.text = String.format(Locale.US, "%.1f um", data.waferBow)
                binding.tvMetWarp.text = String.format(Locale.US, "%.1f um", data.waferWarp)
                binding.tvMetRough.text = String.format(Locale.US, "%.3f nm", data.surfaceRoughness)
                binding.tvMetDefect.text = String.format(Locale.US, "%.3f", data.priorDefectDensity)

                // 2. Process
                binding.tvProcTemp.text = String.format(Locale.US, "%.1f °C", data.chamberTemp)
                binding.tvProcSih4.text = String.format(Locale.US, "%.1f sccm", data.sih4Flow)
                binding.tvProcNh3.text = String.format(Locale.US, "%.1f sccm", data.nh3Flow)
                binding.tvProcN2.text = String.format(Locale.US, "%.1f sccm", data.n2Flow)
                binding.tvProcRf.text = String.format(Locale.US, "%.1f W", data.rfPower)
                binding.tvProcPress.text = String.format(Locale.US, "%.3f torr", data.chamberPressure)
                binding.tvProcTime.text = String.format(Locale.US, "%.1f s", data.processTime)

                // 3. Health
                binding.tvHealRuns.text = data.runsSincePm.toString()
                binding.tvHealO2.text = String.format(Locale.US, "%.3f ppm", data.oxygenLevel)
                binding.tvHealH2o.text = String.format(Locale.US, "%.3f ppm", data.moistureH2O)
                binding.tvHealGasp.text = String.format(Locale.US, "%.2f psi", data.gasLinePressure)
                binding.tvHealSih4v.text = String.format(Locale.US, "%.1f %%", data.sih4ValveOpening)
                binding.tvHealNh3v.text = String.format(Locale.US, "%.1f %%", data.nh3ValveOpening)
                binding.tvHealThrot.text = String.format(Locale.US, "%.1f °", data.throttleValveAngle)

                // 4. ML Predictions (Virtual Metrology)
                binding.tvMlThick.text = String.format(Locale.US, "%.1f nm", data.predictedThickness)
                binding.tvMlUnif.text = String.format(Locale.US, "%.2f %%", data.predictedUniformity)
                binding.tvMlStress.text = String.format(Locale.US, "%.1f MPa", data.predictedStress)
                binding.tvMlRi.text = String.format(Locale.US, "%.3f", data.predictedRefractiveIndex)

                // Alarm
                if (data.alarmActive) {
                    binding.tvAlarmStatus.text = "ALARM"
                    binding.tvAlarmStatus.setBackgroundColor(android.graphics.Color.RED)
                } else {
                    binding.tvAlarmStatus.text = "NORMAL"
                    binding.tvAlarmStatus.setBackgroundColor(android.graphics.Color.parseColor("#4CAF50"))
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
