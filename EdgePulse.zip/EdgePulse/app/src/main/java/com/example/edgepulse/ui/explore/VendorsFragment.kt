package com.example.edgepulse.ui.explore

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.navigation.fragment.findNavController
import com.example.edgepulse.R
import com.example.edgepulse.databinding.FragmentVendorsBinding
import com.example.edgepulse.databinding.ItemVendorBinding

class VendorsFragment : Fragment() {

    private var _binding: FragmentVendorsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVendorsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val equipmentName = arguments?.getString("equipmentName") ?: ""
        val equipment = EquipmentDataProvider.data.find { it.name == equipmentName }

        if (equipment != null) {
            activity?.title = "${equipment.name} Vendors"
            binding.rvVendors.layoutManager = LinearLayoutManager(context)
            binding.rvVendors.adapter = VendorsAdapter(equipment.vendors) { vendor ->
                val bundle = Bundle().apply {
                    putString("vendorName", vendor.name)
                    putString("toolName", vendor.toolSpec.model)
                    putString("toolDesc", vendor.toolSpec.description)
                }
                findNavController().navigate(R.id.action_nav_vendors_to_nav_chat, bundle)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    inner class VendorsAdapter(
        private val items: List<Vendor>,
        private val onVendorClick: (Vendor) -> Unit
    ) : RecyclerView.Adapter<VendorsAdapter.ViewHolder>() {

        inner class ViewHolder(private val itemBinding: ItemVendorBinding) :
            RecyclerView.ViewHolder(itemBinding.root) {
            fun bind(vendor: Vendor) {
                itemBinding.tvVendorName.text = vendor.name
                itemBinding.tvToolModel.text = vendor.toolSpec.model
                itemBinding.tvToolDesc.text = vendor.toolSpec.description
                itemBinding.root.setOnClickListener { onVendorClick(vendor) }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemVendorBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size
    }
}
