package com.example.edgepulse.ui

data class ArduinoData(
    // Previous Metrology (6)
    val incomingThickness: Double = 0.0,
    val incomingStress: Double = 0.0,
    val waferBow: Double = 0.0,
    val waferWarp: Double = 0.0,
    val surfaceRoughness: Double = 0.0,
    val priorDefectDensity: Double = 0.0,

    // Standard Process (7)
    val chamberTemp: Double = 0.0,
    val sih4Flow: Double = 0.0,
    val nh3Flow: Double = 0.0,
    val n2Flow: Double = 0.0,
    val rfPower: Double = 0.0,
    val chamberPressure: Double = 0.0,
    val processTime: Double = 0.0,

    // Equipment Health (7)
    val runsSincePm: Int = 0,
    val oxygenLevel: Double = 0.0,
    val moistureH2O: Double = 0.0,
    val gasLinePressure: Double = 0.0,
    val sih4ValveOpening: Double = 0.0,
    val nh3ValveOpening: Double = 0.0,
    val throttleValveAngle: Double = 0.0,

    // Virtual Metrology Predictions (4)
    val predictedThickness: Double = 0.0,
    val predictedUniformity: Double = 0.0,
    val predictedStress: Double = 0.0,
    val predictedRefractiveIndex: Double = 0.0,

    val alarmActive: Boolean = false
)
