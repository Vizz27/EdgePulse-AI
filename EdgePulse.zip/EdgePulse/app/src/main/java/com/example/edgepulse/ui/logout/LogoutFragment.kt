package com.example.edgepulse.ui.logout

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.edgepulse.R
import com.example.edgepulse.databinding.FragmentLogoutBinding

class LogoutFragment : Fragment() {

    private var _binding: FragmentLogoutBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLogoutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnConfirmLogout.setOnClickListener {
            // Navigate back to landing and clear the entire back stack
            findNavController().navigate(R.id.nav_landing, null,
                androidx.navigation.NavOptions.Builder()
                    .setPopUpTo(R.id.mobile_navigation, true)
                    .build()
            )
        }

        binding.btnCancelLogout.setOnClickListener {
            // Return to the monitoring dashboard
            findNavController().navigate(R.id.nav_monitoring)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}