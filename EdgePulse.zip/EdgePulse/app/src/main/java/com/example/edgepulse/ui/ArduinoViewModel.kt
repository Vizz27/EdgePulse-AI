package com.example.edgepulse.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.Locale
import kotlin.random.Random
import kotlin.time.Duration.Companion.milliseconds

class ArduinoViewModel : ViewModel() {

    private val _arduinoData = MutableStateFlow(ArduinoData())
    val arduinoData: StateFlow<ArduinoData> = _arduinoData

    private val useSimulation = false 
    private var httpBridge: HttpDataBridge? = null

    init {
        if (useSimulation) {
            simulateArduinoData()
        } else {
            startHttpPolling()
        }
    }

    private fun startHttpPolling() {
        httpBridge = HttpDataBridge { jsonString ->
            onDataReceived(jsonString)
        }
        
        viewModelScope.launch {
            while (true) {
                httpBridge?.fetchData()
                delay(500.milliseconds)
            }
        }
    }

    fun onDataReceived(line: String) {
        parseAndSetData(line)
    }

    private fun simulateArduinoData() {
        viewModelScope.launch {
            // Initial values
            var thick = 100.0; var stress = -45.0; var bow = 12.0; var warp = 22.0; var rough = 0.35; var defect = 0.05
            var temp = 400.0; var sih4 = 100.0; var nh3 = 220.0; var n2 = 1000.0; var rf = 600.0; var press = 2.0; var time = 60.0
            var runs = 50; var oxy = 0.05; var moist = 0.02; var gasP = 30.0; var sih4V = 66.7; var nh3V = 73.3; var throt = 56.0

            while (true) {
                delay(500.milliseconds)
                val drift = if (Random.nextBoolean()) 0.1 else -0.1
                
                thick += drift; stress += drift * 2; bow += drift; warp += drift; rough += drift * 0.01; defect += drift * 0.001
                temp += drift * 5; sih4 += drift; nh3 += drift * 2; n2 += drift * 5; rf += drift * 5; press += drift * 0.01; time += drift
                oxy += drift * 0.001; moist += drift * 0.001; gasP += drift * 0.1; throt += drift * 0.5

                val alarm = temp < 380 || temp > 420 || press < 1.5 || press > 2.5

                val json = JSONObject().apply {
                    put("KOTLIN_DATA", true)
                    put("incoming_thickness_nm", thick)
                    put("incoming_stress_mpa", stress)
                    put("wafer_bow_um", bow)
                    put("wafer_warp_um", warp)
                    put("surface_roughness_ra_nm", rough)
                    put("prior_defect_density", defect)
                    put("chamber_temp_c", temp)
                    put("sih4_flow_sccm", sih4)
                    put("nh3_flow_sccm", nh3)
                    put("n2_flow_sccm", n2)
                    put("rf_power_w", rf)
                    put("chamber_pressure_torr", press)
                    put("process_time_sec", time)
                    put("runs_since_pm", runs)
                    put("oxygen_level_ppm", oxy)
                    put("moisture_h2o_ppm", moist)
                    put("gas_line_pressure_psi", gasP)
                    put("sih4_mfc_valve_opening_pct", sih4V)
                    put("nh3_mfc_valve_opening_pct", nh3V)
                    put("throttle_valve_angle_deg", throt)
                    
                    // Simulated predictions
                    put("target_thickness_nm", thick + 5.0)
                    put("target_uniformity_sigma", 0.8)
                    put("target_film_stress_mpa", stress + 2.0)
                    put("target_refractive_index", 1.45)
                    
                    put("alarm_active", alarm)
                }

                onDataReceived(json.toString())
            }
        }
    }

    private fun parseAndSetData(line: String) {
        try {
            val json = JSONObject(line)
            val newData = ArduinoData(
                incomingThickness = json.optDouble("incoming_thickness_nm", 0.0),
                incomingStress = json.optDouble("incoming_stress_mpa", 0.0),
                waferBow = json.optDouble("wafer_bow_um", 0.0),
                waferWarp = json.optDouble("wafer_warp_um", 0.0),
                surfaceRoughness = json.optDouble("surface_roughness_ra_nm", 0.0),
                priorDefectDensity = json.optDouble("prior_defect_density", 0.0),
                chamberTemp = json.optDouble("chamber_temp_c", 0.0),
                sih4Flow = json.optDouble("sih4_flow_sccm", 0.0),
                nh3Flow = json.optDouble("nh3_flow_sccm", 0.0),
                n2Flow = json.optDouble("n2_flow_sccm", 0.0),
                rfPower = json.optDouble("rf_power_w", 0.0),
                chamberPressure = json.optDouble("chamber_pressure_torr", 0.0),
                processTime = json.optDouble("process_time_sec", 0.0),
                runsSincePm = json.optInt("runs_since_pm", 0),
                oxygenLevel = json.optDouble("oxygen_level_ppm", 0.0),
                moistureH2O = json.optDouble("moisture_h2o_ppm", 0.0),
                gasLinePressure = json.optDouble("gas_line_pressure_psi", 0.0),
                sih4ValveOpening = json.optDouble("sih4_mfc_valve_opening_pct", 0.0),
                nh3ValveOpening = json.optDouble("nh3_mfc_valve_opening_pct", 0.0),
                throttleValveAngle = json.optDouble("throttle_valve_angle_deg", 0.0),
                
                // ML Predictions (Virtual Metrology)
                predictedThickness = json.optDouble("target_thickness_nm", 0.0),
                predictedUniformity = json.optDouble("target_uniformity_sigma", 0.0),
                predictedStress = json.optDouble("target_film_stress_mpa", 0.0),
                predictedRefractiveIndex = json.optDouble("target_refractive_index", 0.0),

                alarmActive = json.optBoolean("alarm_active", false)
            )
            _arduinoData.value = newData
        } catch (e: Exception) { }
    }
}
