package com.example.edgepulse.ui

import okhttp3.*
import java.io.IOException

class HttpDataBridge(private val onDataReceived: (String) -> Unit) {

    private val client = OkHttpClient()
    // IMPORTANT: Replace with your PC's actual local IP address
    private val serverUrl = "http://10.91.62.124:5000/telemetry"

    fun fetchData() {
        val request = Request.Builder()
            .url(serverUrl)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Connection error (server might be down)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { 
                    if (it.isSuccessful) {
                        it.body?.string()?.let { json ->
                            onDataReceived(json)
                        }
                    }
                }
            }
        })
    }
}
